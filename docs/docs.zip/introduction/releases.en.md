﻿---
order: 5
title: Releases
---

## v.1.0.3
- namespace refactoring

## v.1.0.2
- ironing concurrent execution
- functions to work with decimal
- version change

## v.1.0.1
- adding contexts to result item
- number of rows used in the result item processing
- adding process errors in the result item context and property HasErros in the result item

## v.1.0.0
Initial release